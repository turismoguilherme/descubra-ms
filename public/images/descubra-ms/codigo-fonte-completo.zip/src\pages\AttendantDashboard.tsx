import React from 'react';
import AttendantDashboardRestored from '@/components/cat/AttendantDashboardRestored';

const AttendantDashboard = () => {
  return <AttendantDashboardRestored />;
};

export default AttendantDashboard;


