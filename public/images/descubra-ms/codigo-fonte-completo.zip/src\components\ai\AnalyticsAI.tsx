import React from 'react';
import AnalyticsAISimple from './AnalyticsAISimple';

const AnalyticsAI = () => {
  return <AnalyticsAISimple />;
};

export default AnalyticsAI;