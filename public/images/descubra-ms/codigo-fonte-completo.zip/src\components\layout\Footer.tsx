
import UniversalFooter from "./UniversalFooter";

const Footer = () => {
  return <UniversalFooter />;
};

export default Footer;
