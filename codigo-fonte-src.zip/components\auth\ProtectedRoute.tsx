import { ReactNode, useState, useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

interface ProtectedRouteProps {
  children: ReactNode;
  allowedRoles?: string[];
  requireRegion?: boolean;
  requireCity?: boolean;
}

export function ProtectedRoute({
  children,
  allowedRoles = [],
  requireRegion = false,
  requireCity = false
}: ProtectedRouteProps) {
  const { user, userProfile, loading } = useAuth();
  const location = useLocation();
  const [waitingForTestUser, setWaitingForTestUser] = useState(false);

  // Verificar se há usuário de teste no localStorage e aguardar processamento
  useEffect(() => {
    const testUserId = localStorage.getItem('test_user_id');
    const testUserData = localStorage.getItem('test_user_data');
    
    if (!user && testUserId && testUserData && !waitingForTestUser) {
      console.log('🔐 ProtectedRoute: Usuário de teste detectado, aguardando processamento...');
      setWaitingForTestUser(true);
      
      // Aguardar até 3 segundos para o AuthProvider processar
      const timeout = setTimeout(() => {
        console.log('🔐 ProtectedRoute: Timeout aguardando usuário de teste, continuando...');
        setWaitingForTestUser(false);
      }, 3000);
      
      return () => clearTimeout(timeout);
    }
    
    if (user && waitingForTestUser) {
      console.log('🔐 ProtectedRoute: Usuário de teste processado pelo AuthProvider');
      setWaitingForTestUser(false);
    }
  }, [user, waitingForTestUser]);

  // Aguardar carregamento inicial ou usuário de teste
  if (loading || waitingForTestUser) {
    console.log('🔐 ProtectedRoute: loading=true ou aguardando usuário de teste, aguardando...');
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Carregando...</p>
        </div>
      </div>
    );
  }

  // Debug: Log do estado atual
  console.log('🔐 ProtectedRoute: Verificando acesso:', {
    user: user ? { id: user.id, email: user.email } : null,
    userProfile: userProfile ? { user_id: userProfile.user_id, role: userProfile.role } : null,
    loading,
    pathname: location.pathname,
    allowedRoles
  });

  // Verificar se há usuário de teste no localStorage (fallback)
  const testUserId = localStorage.getItem('test_user_id');
  const testUserData = localStorage.getItem('test_user_data');
  
  if (!user && testUserId && testUserData) {
    console.log('🔐 ProtectedRoute: Usuário de teste encontrado no localStorage, processando imediatamente...');
    
    try {
      const testUser = JSON.parse(testUserData);
      console.log('🔐 ProtectedRoute: Processando usuário de teste:', testUser);
      console.log('🔐 ProtectedRoute: Roles permitidos:', allowedRoles);
      console.log('🔐 ProtectedRoute: Rota atual:', location.pathname);
      
      // Verificar se o role do usuário de teste está permitido
      if (allowedRoles.length > 0 && !allowedRoles.includes(testUser.role)) {
        console.warn('🔐 ProtectedRoute: Role de usuário de teste não permitida:', {
          userRole: testUser.role,
          allowedRoles,
          pathname: location.pathname
        });
        
        // Para usuários de teste com role não permitida, redirecionar para test-login
        return <Navigate to="/test-login" replace />;
      }
      
      console.log('🔐 ProtectedRoute: Acesso liberado para usuário de teste com role:', testUser.role);
      
      // Para usuários de teste, permitir acesso direto sem redirecionamento
      // O AuthProvider processará em background
      return <>{children}</>;
    } catch (error) {
      console.error('🔐 ProtectedRoute: Erro ao processar usuário de teste:', error);
      // Se houver erro, aguardar o AuthProvider
      return <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Carregando usuário de teste...</p>
        </div>
      </div>;
    }
  }

  // Se não há usuário de teste no localStorage, mas ainda está carregando, aguardar mais
  if (!user && !testUserId && loading) {
    console.log('🔐 ProtectedRoute: Aguardando AuthProvider carregar...');
    return <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p>Aguardando autenticação...</p>
      </div>
    </div>;
  }

  // Verificar autenticação (apenas para usuários reais)
  if (!user && !testUserId) {
    // Redirecionar para o login correto baseado na rota
    const isViaJARRoute = location.pathname.startsWith('/viajar') || 
                         location.pathname.startsWith('/attendant-dashboard') || 
                         location.pathname.startsWith('/secretary-dashboard') || 
                         location.pathname.startsWith('/private-dashboard') || 
                         location.pathname.startsWith('/unified');
    const loginPath = isViaJARRoute ? '/viajar/login' : '/ms/login';
    console.warn('🔐 ProtectedRoute: usuário não autenticado. Redirecionando para', loginPath, { from: location.pathname });
    return <Navigate to={loginPath} state={{ from: location }} replace />;
  }

  // Verificar perfil do usuário (apenas para usuários reais)
  if (!userProfile && !testUserId) {
    // Redirecionar para o login correto baseado na rota
    const isViaJARRoute = location.pathname.startsWith('/viajar') || 
                         location.pathname.startsWith('/attendant-dashboard') || 
                         location.pathname.startsWith('/secretary-dashboard') || 
                         location.pathname.startsWith('/private-dashboard') || 
                         location.pathname.startsWith('/unified');
    const loginPath = isViaJARRoute ? '/viajar/login' : '/ms/login';
    console.warn('🔐 ProtectedRoute: userProfile ausente. Redirecionando para', loginPath, { from: location.pathname });
    return <Navigate to={loginPath} state={{ from: location }} replace />;
  }

  // Determinar o role do usuário (para usuários de teste, verificar o localStorage)
  let userRole = userProfile?.role || 'user'; // Valor padrão
  if (testUserId && testUserData) {
    try {
      const testUser = JSON.parse(testUserData);
      userRole = testUser.role;
      console.log('🔐 ProtectedRoute: Verificando role de usuário de teste:', userRole);
    } catch (error) {
      console.error('🔐 ProtectedRoute: Erro ao processar usuário de teste para verificação de role:', error);
      userRole = 'user'; // Fallback para user
    }
  }

  // Verificar permissões de role
  if (allowedRoles.length > 0) {
    if (!allowedRoles.includes(userRole)) {
      // Redirecionar para o login correto baseado na rota
      const isViaJARRoute = location.pathname.startsWith('/viajar') || 
                           location.pathname.startsWith('/attendant-dashboard') || 
                           location.pathname.startsWith('/secretary-dashboard') || 
                           location.pathname.startsWith('/private-dashboard') || 
                           location.pathname.startsWith('/unified');
      const loginPath = isViaJARRoute ? '/viajar/login' : '/ms/login';
      console.warn('🔐 ProtectedRoute: role não permitida.', { 
        userRole, 
        allowedRoles, 
        from: location.pathname,
        isTestUser: !!testUserId 
      });
      return <Navigate to={loginPath} replace />;
    }
  }

  // Verificar região se necessário
  if (requireRegion && !userProfile.region_id) {
    console.warn('🔐 ProtectedRoute: requireRegion habilitado e region_id ausente. Redirecionando para /ms/select-region', { from: location.pathname });
    return <Navigate to="/ms/select-region" replace />;
  }

  // Verificar cidade se necessário
  if (requireCity && !userProfile.city_id) {
    console.warn('🔐 ProtectedRoute: requireCity habilitado e city_id ausente. Redirecionando para /ms/select-city', { from: location.pathname });
    return <Navigate to="/ms/select-city" replace />;
  }

  // Verificações específicas por role
  const currentRole = userRole || userProfile?.role || 'user';
  switch (currentRole) {
    case 'master_admin':
      console.log('🔐 ProtectedRoute: acesso total (master_admin)');
      return <>{children}</>;

    case 'state_admin':
      if (!userProfile.region_id) {
        console.warn('🔐 ProtectedRoute: state_admin sem region_id. Redirecionando para /ms/select-region');
        return <Navigate to="/ms/select-region" replace />;
      }
      break;

    case 'city_admin':
      if (!userProfile.city_id) {
        console.warn('🔐 ProtectedRoute: city_admin sem city_id. Redirecionando para /ms/select-city');
        return <Navigate to="/ms/select-city" replace />;
      }
      break;

    case 'cat_attendant':
      // Verificar se tem CAT associado (apenas para usuários reais, não de teste)
      if (!(userProfile as any).cat_id && !testUserId) {
        console.warn('🔐 ProtectedRoute: cat_attendant sem cat_id. Redirecionando para /ms/select-cat');
        return <Navigate to="/ms/select-cat" replace />;
      }
      break;

    case 'collaborator':
      // Verificar se tem permissões necessárias
      if (!(userProfile as any).permissions?.length) {
        console.warn('🔐 ProtectedRoute: collaborator sem permissions. Redirecionando para /ms/pending-approval');
        return <Navigate to="/ms/pending-approval" replace />;
      }
      break;

    default:
      console.log('🔐 ProtectedRoute: usuário regular, acesso liberado.');
      break;
  }

  return <>{children}</>;
}