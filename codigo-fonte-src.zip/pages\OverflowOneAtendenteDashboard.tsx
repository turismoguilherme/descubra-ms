import React from 'react';
import AtendenteDashboard from '@/components/admin/dashboards/AtendenteDashboard';

const OverflowOneAtendenteDashboard: React.FC = () => {
  return <AtendenteDashboard />;
};

export default OverflowOneAtendenteDashboard;




