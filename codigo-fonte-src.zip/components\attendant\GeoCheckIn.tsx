import React from 'react';
import GeoCheckInSimple from './GeoCheckInSimple';

const GeoCheckIn = () => {
  return <GeoCheckInSimple />;
};

export default GeoCheckIn;