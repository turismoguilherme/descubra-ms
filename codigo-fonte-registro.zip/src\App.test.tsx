import React from 'react';

const AppTest = () => {
  return (
    <div style={{ padding: '20px', backgroundColor: 'lightblue' }}>
      <h1>TESTE - Aplicação Funcionando</h1>
      <p>Se você vê isso, o React está funcionando!</p>
    </div>
  );
};

export default AppTest;

