import React from 'react';
import RewardsManagerAdmin from '../admin/RewardsManager';

const RewardsManager = () => {
  return <RewardsManagerAdmin />;
};

export default RewardsManager;