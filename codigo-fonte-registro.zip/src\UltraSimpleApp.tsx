import React from 'react';

const UltraSimpleApp = () => {
  return (
    <div>
      <h1>FUNCIONANDO!</h1>
      <p>Se você vê isso, o React está funcionando.</p>
    </div>
  );
};

export default UltraSimpleApp;
